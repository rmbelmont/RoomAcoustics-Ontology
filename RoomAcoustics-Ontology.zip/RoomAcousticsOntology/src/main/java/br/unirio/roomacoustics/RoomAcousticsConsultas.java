package br.unirio.roomacoustics;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.*;

import java.io.File;
import java.util.*;

/**
 * Consultas de competência (CQ1–CQ6) para a Room Acoustics Ontology.
 * Implementadas 100% com OWL API 5.x.
 *
 * Todas as consultas mostram os INDIVÍDUOS (instâncias) envolvidos,
 * não apenas SIM/NÃO.
 */
public class RoomAcousticsConsultas {

    private static final String NS =
            "http://www.unirio.br/roomacoustics/ontology#";

    private static final String ONTOLOGY_PATH =
            "./ontology/room-acoustics-ontology.rdf";

    private static final String PDF_OUTPUT_PATH =
            "./ontology/room-acoustics-report.pdf";

    private static final String SEP =
            "============================================================";

    @FunctionalInterface
    private interface AcousticsRule {
        boolean matches(Map<String, Double> values);
    }

    // ============================================================
    // Estado
    // ============================================================
    private OWLOntologyManager manager;
    private OWLOntology ontology;
    private OWLDataFactory factory;

    private OWLClass roomClass;
    private OWLClass soundEffectClass;

    private final Map<String, AcousticsRule> rules =
            new LinkedHashMap<>();

    private final Map<String, OWLClass> effectClasses =
            new LinkedHashMap<>();

    // ============================================================
    // Construtor
    // ============================================================
    public RoomAcousticsConsultas() throws Exception {
        loadOntology();
        resolveClasses();
        initRules();
        materializeInferences();
        printInstancesSummary();
        showMenu();
    }

    // ============================================================
    // 1) Carregar ontologia
    // ============================================================
    private void loadOntology() throws Exception {
        manager = OWLManager.createOWLOntologyManager();
        factory = manager.getOWLDataFactory();

        File f = new File(ONTOLOGY_PATH);
        if (!f.exists()) {
            throw new Exception("Ontologia não encontrada: " + f.getAbsolutePath());
        }

        ontology = manager.loadOntologyFromOntologyDocument(f);

        System.out.println("Ontologia carregada: " + f.getAbsolutePath());
        System.out.println("Axiomas:   " + ontology.getAxiomCount());
        System.out.println("Classes:   " + ontology.getClassesInSignature().size());
        System.out.println("Indivíduos: " + ontology.getIndividualsInSignature().size());
    }

    // ============================================================
    // 2) Resolver classes
    // ============================================================
    private void resolveClasses() {
        roomClass = factory.getOWLClass(IRI.create(NS + "Room"));
        soundEffectClass = factory.getOWLClass(IRI.create(NS + "SoundEffect"));

        for (OWLSubClassOfAxiom ax :
                ontology.getSubClassAxiomsForSuperClass(soundEffectClass)) {
            OWLClassExpression sub = ax.getSubClass();
            if (sub.isNamed()) {
                OWLClass c = sub.asOWLClass();
                effectClasses.put(shortName(c), c);
            }
        }

        System.out.println("Efeitos descobertos: " + effectClasses.size());
    }

    // ============================================================
    // 3) Regras SWRL
    // ============================================================
    private void initRules() {
        rules.put("Echo", m ->
                v(m, "hasRT60") > 1.5 && v(m, "hasV") > 1000 && v(m, "hasDR") < -5);
        rules.put("Reverberance", m -> v(m, "hasEDT") > 1.8);
        rules.put("Liveness", m ->
                v(m, "hasRT60") > 1.0 && v(m, "hasRT60") < 1.8 && v(m, "hasG") > 0);
        rules.put("Dry", m ->
                v(m, "hasRT60") < 0.6 && v(m, "hasAlpha") > 0.5);
        rules.put("Intimacy", m -> v(m, "hasITDG") < 20);
        rules.put("Spaciousness", m ->
                v(m, "hasLF") > 0.2 && v(m, "hasIACC") < 0.35);
        rules.put("Acoustic_distance", m -> v(m, "hasDR") < -8);
        rules.put("Fullness", m ->
                v(m, "hasG") > 5 && v(m, "hasRT60") > 1.2);
        rules.put("Warmth", m ->
                v(m, "hasBR") > 1.1 && v(m, "hasBR") < 1.45);
        rules.put("Cold", m -> v(m, "hasBR") < 0.9);
        rules.put("Bright", m ->
                v(m, "hasDeltaH") > 2 && v(m, "hasDeltaH") < 6);
        rules.put("Brilliant", m -> v(m, "hasDeltaH") > 5);
        rules.put("Dark", m -> v(m, "hasDeltaH") < -3);
        rules.put("Thin", m -> v(m, "hasDeltaL") < -4);
        rules.put("Boomy", m ->
                v(m, "hasDeltaL") > 5 && v(m, "hasRT60") > 1.0);
        rules.put("Wooly", m -> v(m, "hasDeltaL") > 3);
        rules.put("Boxy", m -> v(m, "hasDeltaM") > 4);
        rules.put("Nasal", m -> v(m, "hasDeltaM") > 3);
        rules.put("Cupped-hands", m -> v(m, "hasDeltaM") > 5);
        rules.put("Steely", m -> v(m, "hasDeltaH") > 6);
        rules.put("Sibilance", m -> v(m, "hasDeltaH") > 4);
        rules.put("Muffed", m ->
                v(m, "hasAlpha") > 0.7 && v(m, "hasDeltaH") < -5);
        rules.put("Horizontal_clarity", m -> v(m, "hasC80") > 2);
        rules.put("Intelligibility", m -> v(m, "hasD50") > 0.5);
        rules.put("Closed-in", m ->
                v(m, "hasC80") < -2 && v(m, "hasG") < -2);
        rules.put("Ringing", m ->
                v(m, "hasRT60") > 2.5 && v(m, "hasV") < 200);
        rules.put("Presence_range", m ->
                v(m, "hasDeltaM") > 2 && v(m, "hasC80") > 1);
        rules.put("Thick", m -> v(m, "hasDeltaL") > 4);
    }

    private static double v(Map<String, Double> m, String k) {
        return m.getOrDefault(k, Double.NaN);
    }

    // ============================================================
    // 4) Materialização
    // ============================================================
    private void materializeInferences() {
        int total = 0;

        for (OWLNamedIndividual room : getRooms()) {
            Map<String, Double> values = readValues(room);

            for (Map.Entry<String, AcousticsRule> e : rules.entrySet()) {
                String effectName = e.getKey();
                OWLClass effectClass = effectClasses.get(effectName);
                if (effectClass == null) continue;

                try {
                    if (e.getValue().matches(values)) {
                        OWLClassAssertionAxiom ax =
                                factory.getOWLClassAssertionAxiom(effectClass, room);
                        if (!ontology.containsAxiom(ax)) {
                            manager.addAxiom(ontology, ax);
                            total++;
                        }
                    }
                } catch (Exception ignored) { }
            }
        }

        System.out.println("Inferências materializadas: " + total + " axiomas.");
    }

    // ============================================================
    // ★ NOVO: sumário de instâncias no boot
    // ============================================================
    private void printInstancesSummary() {
        System.out.println("\n" + SEP);
        System.out.println("INSTÂNCIAS (INDIVÍDUOS) NA ONTOLOGIA");
        System.out.println(SEP);

        List<OWLNamedIndividual> rooms = getRooms();
        System.out.println("\nInstâncias de Room (" + rooms.size() + "):");
        for (OWLNamedIndividual r : rooms) {
            System.out.println("  • " + shortName(r));
        }

        System.out.println("\nInstâncias por classe de efeito:");
        int totalInferred = 0;
        for (String eff : effectClasses.keySet()) {
            List<OWLNamedIndividual> inds = getRoomsWithEffect(eff);
            if (inds.isEmpty()) continue;
            totalInferred += inds.size();
            System.out.printf("  %-22s → %d instância(s): ", eff, inds.size());
            List<String> names = new ArrayList<>();
            for (OWLNamedIndividual i : inds) names.add(shortName(i));
            System.out.println(String.join(", ", names));
        }
        System.out.println("\nTotal de asserções sala×efeito: " + totalInferred);
        System.out.println(SEP + "\n");
    }

    // ============================================================
    // Helpers OWL API
    // ============================================================
    private String shortName(OWLNamedObject obj) {
        return obj.getIRI().getShortForm();
    }

    private Map<String, Double> readValues(OWLNamedIndividual room) {
        Map<String, Double> values = new HashMap<>();
        for (OWLDataPropertyAssertionAxiom ax :
                ontology.getDataPropertyAssertionAxioms(room)) {
            String key = shortName(ax.getProperty().asOWLDataProperty());
            try {
                values.put(key, Double.parseDouble(ax.getObject().getLiteral()));
            } catch (Exception ignored) { }
        }
        return values;
    }

    private List<OWLNamedIndividual> getRooms() {
        Set<OWLNamedIndividual> rooms = new LinkedHashSet<>();
        for (OWLClassAssertionAxiom ax :
                ontology.getClassAssertionAxioms(roomClass)) {
            OWLIndividual ind = ax.getIndividual();
            if (ind.isNamed()) rooms.add(ind.asOWLNamedIndividual());
        }
        if (rooms.isEmpty()) {
            for (OWLNamedIndividual ind : ontology.getIndividualsInSignature()) {
                if (shortName(ind).startsWith("case")) {
                    rooms.add(ind);
                }
            }
        }
        List<OWLNamedIndividual> list = new ArrayList<>(rooms);
        list.sort(Comparator.comparing(this::shortName));
        return list;
    }

    private OWLNamedIndividual getRoom(String id) {
        return factory.getOWLNamedIndividual(IRI.create(NS + id));
    }

    private OWLClass getEffectClass(String name) {
        OWLClass c = effectClasses.get(name);
        if (c == null) c = factory.getOWLClass(IRI.create(NS + name));
        return c;
    }

    private boolean hasEffect(OWLNamedIndividual room, String effectName) {
        OWLClass effectClass = getEffectClass(effectName);
        return ontology.containsAxiom(
                factory.getOWLClassAssertionAxiom(effectClass, room));
    }

    private List<OWLNamedIndividual> getRoomsWithEffect(String effectName) {
        OWLClass effectClass = getEffectClass(effectName);
        List<OWLNamedIndividual> result = new ArrayList<>();
        for (OWLClassAssertionAxiom ax :
                ontology.getClassAssertionAxioms(effectClass)) {
            OWLIndividual ind = ax.getIndividual();
            if (ind.isNamed()) {
                OWLNamedIndividual n = ind.asOWLNamedIndividual();
                if (ontology.containsAxiom(
                        factory.getOWLClassAssertionAxiom(roomClass, n))) {
                    result.add(n);
                }
            }
        }
        result.sort(Comparator.comparing(this::shortName));
        return result;
    }

    /** Lista todos os efeitos que uma sala tem (matriz por linha). */
    private List<String> getEffectsOf(OWLNamedIndividual room) {
        List<String> effects = new ArrayList<>();
        for (String eff : effectClasses.keySet()) {
            if (hasEffect(room, eff)) effects.add(eff);
        }
        Collections.sort(effects);
        return effects;
    }

    // ============================================================
    // CQ1 — mostra individuos e efeitos
    // ============================================================
    private void cq1() {
        printHeader("CQ1 — Efeitos inferidos para case1");
        System.out.println("Pergunta: Reverberance, Intimacy, Horizontal_clarity e");
        System.out.println("          Intelligibility são inferidos para case1?");

        OWLNamedIndividual case1 = getRoom("case1");
        System.out.println("\nIndivíduo consultado: " + shortName(case1));

        String[] asked = {
                "Reverberance", "Intimacy",
                "Horizontal_clarity", "Intelligibility"
        };

        int found = 0;
        System.out.println("\nEfeitos verificados neste indivíduo:");
        for (String e : asked) {
            boolean ok = hasEffect(case1, e);
            if (ok) found++;
            System.out.printf("  %-20s : %s%n", e,
                    ok ? "SIM (assertion presente)" : "NÃO (sem assertion)");
        }

        System.out.println("\nTodos os 4? "
                + (found == asked.length ? "SIM" : "NÃO (" + found + "/4)"));

        List<String> allEffects = getEffectsOf(case1);
        System.out.println("\nTodos os efeitos inferidos para " + shortName(case1)
                + " (" + allEffects.size() + "):");
        for (String e : allEffects) System.out.println("  • " + e);
    }

    // ============================================================
    // CQ2 — hierarquia e instâncias
    // ============================================================
    private void cq2() {
        printHeader("CQ2 — Classe inferida quando EDT > 1.8 s");

        OWLClass rev = getEffectClass("Reverberance");
        System.out.println("Classe inferida : Reverberance");
        System.out.println("Regra SWRL      : EDT > 1.8");

        List<String> chain = new ArrayList<>();
        chain.add(shortName(rev));
        OWLClass current = rev;
        for (int i = 0; i < 5; i++) {
            OWLClass parent = null;
            for (OWLSubClassOfAxiom ax :
                    ontology.getSubClassAxiomsForSubClass(current)) {
                OWLClassExpression sup = ax.getSuperClass();
                if (sup.isNamed()) { parent = sup.asOWLClass(); break; }
            }
            if (parent == null || parent.isOWLThing()) break;
            chain.add(shortName(parent));
            current = parent;
        }
        System.out.println("\nHierarquia (subClassOf):");
        for (int i = 0; i < chain.size(); i++) {
            System.out.println("  " + "  ".repeat(i)
                    + (i == 0 ? "" : "↳ ") + chain.get(i));
        }

        List<OWLNamedIndividual> inds = getRoomsWithEffect("Reverberance");
        System.out.println("\nInstâncias de Reverberance (" + inds.size() + "):");
        for (OWLNamedIndividual i : inds) System.out.println("  • " + shortName(i));
    }

    // ============================================================
    // CQ3 — mostra individuos e efeitos
    // ============================================================
    private void cq3() {
        printHeader("CQ3 — Efeitos inferidos para case2");

        OWLNamedIndividual case2 = getRoom("case2");
        System.out.println("Indivíduo consultado: " + shortName(case2));

        String[] asked = {
                "Dry", "Horizontal_clarity",
                "Intelligibility", "Intimacy"
        };

        System.out.println("\nEfeitos verificados:");
        for (String e : asked) {
            boolean ok = hasEffect(case2, e);
            System.out.printf("  %-20s : %s%n", e,
                    ok ? "SIM" : "NÃO");
        }

        List<String> allEffects = getEffectsOf(case2);
        System.out.println("\nTodos os efeitos inferidos para " + shortName(case2)
                + " (" + allEffects.size() + "):");
        for (String e : allEffects) System.out.println("  • " + e);
    }

    // ============================================================
    // CQ4 — lista os indivíduos com Reverberance
    // ============================================================
    private void cq4() {
        printHeader("CQ4 — Registros com a classe Reverberance");

        List<OWLNamedIndividual> rooms = getRoomsWithEffect("Reverberance");

        System.out.println("Instâncias de Reverberance (" + rooms.size() + "):");
        for (OWLNamedIndividual r : rooms) {
            System.out.println("\n  • " + shortName(r));
            Map<String, Double> vals = readValues(r);
            System.out.println("    valores de data properties:");
            for (Map.Entry<String, Double> e : vals.entrySet()) {
                System.out.printf("      %-14s = %.3f%n",
                        e.getKey(), e.getValue());
            }
            List<String> eff = getEffectsOf(r);
            System.out.println("    efeitos inferidos: "
                    + (eff.isEmpty() ? "(nenhum)" : String.join(", ", eff)));
        }
    }

    // ============================================================
    // CQ5 — 4 efeitos simultâneos, mostra instâncias
    // ============================================================
    private void cq5() {
        printHeader("CQ5 — Efeitos simultâneos para case43");

        OWLNamedIndividual case43 = getRoom("case43");
        System.out.println("Indivíduo consultado: " + shortName(case43));

        String[] asked = {
                "Reverberance", "Acoustic_distance",
                "Fullness", "Ringing"
        };

        int found = 0;
        System.out.println("\nEfeitos verificados neste indivíduo:");
        for (String e : asked) {
            boolean ok = hasEffect(case43, e);
            if (ok) found++;
            System.out.printf("  %-20s : %s%n", e, ok ? "SIM" : "NÃO");
        }

        System.out.println("\nTodos os 4 simultâneos? "
                + (found == asked.length ? "SIM" : "NÃO (" + found + "/4)"));

        List<String> allEffects = getEffectsOf(case43);
        System.out.println("\nTodos os efeitos inferidos para " + shortName(case43)
                + " (" + allEffects.size() + "):");
        for (String e : allEffects) System.out.println("  • " + e);
    }

    // ============================================================
    // CQ6 — contagem Dry, mostra instâncias
    // ============================================================
    private void cq6() {
        printHeader("CQ6 — Quantidade de registros com Dry");

        List<OWLNamedIndividual> rooms = getRoomsWithEffect("Dry");

        System.out.println("Instâncias de Dry (" + rooms.size() + "):");
        if (rooms.isEmpty()) {
            System.out.println("  (nenhuma instância — regra RT60<0.6 AND alpha>0.5");
            System.out.println("   não é satisfeita por nenhuma sala do corpus)");
        } else {
            for (OWLNamedIndividual r : rooms) {
                System.out.println("  • " + shortName(r));
            }
        }
    }

    // ============================================================
    // NOVO — opção 8: detalhar todos os indivíduos
    // ============================================================
    private void listAllIndividuals() {
        printHeader("TODOS OS INDIVÍDUOS DA ONTOLOGIA (detalhado)");

        System.out.println("Indivíduos na assinatura: "
                + ontology.getIndividualsInSignature().size());

        for (OWLNamedIndividual ind : ontology.getIndividualsInSignature()) {
            String id = shortName(ind);
            System.out.println("\n──────────────────────────────────────────");
            System.out.println("Indivíduo: " + id);
            System.out.println("IRI completo: " + ind.getIRI());

            List<String> types = new ArrayList<>();
            for (OWLClassAssertionAxiom ax :
                    ontology.getClassAssertionAxioms(ind)) {
                OWLClassExpression ce = ax.getClassExpression();
                if (ce.isNamed()) {
                    types.add(shortName(ce.asOWLClass()));
                }
            }
            System.out.println("Classes (" + types.size() + "): "
                    + String.join(", ", types));

            Map<String, Double> vals = readValues(ind);
            if (!vals.isEmpty()) {
                System.out.println("Data properties (" + vals.size() + "):");
                for (Map.Entry<String, Double> e : vals.entrySet()) {
                    System.out.printf("   %-14s = %.3f%n",
                            e.getKey(), e.getValue());
                }
            }
        }
    }

    // ============================================================
    // NOVO — opção 9: matriz sala × efeito
    // ============================================================
    private void printEffectMatrix() {
        printHeader("MATRIZ SALA × EFEITO (asserções materializadas)");

        List<OWLNamedIndividual> rooms = getRooms();
        List<String> effects = new ArrayList<>(effectClasses.keySet());
        Collections.sort(effects);

        System.out.printf("%-14s", "Sala");
        for (String eff : effects) {
            System.out.printf(" %-6s", abbrev(eff));
        }
        System.out.println();

        System.out.printf("%-14s", "");
        for (int i = 0; i < effects.size(); i++) System.out.print("  ──── ");
        System.out.println();

        for (OWLNamedIndividual room : rooms) {
            System.out.printf("%-14s", shortName(room));
            for (String eff : effects) {
                System.out.printf(" %-6s", hasEffect(room, eff) ? "✓" : "·");
            }
            System.out.println();
        }

        System.out.println("\nLegenda:");
        for (int i = 0; i < effects.size(); i++) {
            System.out.printf("  %-6s = %s%n",
                    abbrev(effects.get(i)), effects.get(i));
        }
    }

    private String abbrev(String effect) {
        String s = effect.replace("-", "")
                .replace("_", "");
        return s.length() <= 6 ? s : s.substring(0, 6);
    }

    // ============================================================
    // PDF
    // ============================================================
    private void generatePDF() {
        printHeader("Gerando relatório PDF...");
        try {
            RoomAcousticsPDFGenerator gen =
                    new RoomAcousticsPDFGenerator(this.ontology);
            gen.generatePDF(PDF_OUTPUT_PATH);
            System.out.println("\nPDF gerado: " + PDF_OUTPUT_PATH);
        } catch (Exception e) {
            System.err.println("Erro ao gerar PDF: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // ============================================================
    // MENU
    // ============================================================
    private void showMenu() {
        Scanner sc = new Scanner(System.in);
        int op;

        do {
            printHeader("Room Acoustics Ontology — Consultas (OWL API 5.x)");
            System.out.println("1 - CQ1: efeitos para case1");
            System.out.println("2 - CQ2: hierarquia de Reverberance + instâncias");
            System.out.println("3 - CQ3: efeitos para case2");
            System.out.println("4 - CQ4: instâncias com Reverberance");
            System.out.println("5 - CQ5: 4 efeitos simultâneos em case43");
            System.out.println("6 - CQ6: instâncias com Dry");
            System.out.println("7 - Gerar relatório PDF");
            System.out.println("8 - Listar TODOS os indivíduos da ontologia");
            System.out.println("9 - Matriz sala × efeito");
            System.out.println("0 - Sair");
            System.out.print("Opção: ");

            try {
                op = Integer.parseInt(sc.nextLine().trim());
            } catch (Exception e) {
                op = -1;
            }

            switch (op) {
                case 1: cq1(); break;
                case 2: cq2(); break;
                case 3: cq3(); break;
                case 4: cq4(); break;
                case 5: cq5(); break;
                case 6: cq6(); break;
                case 7: generatePDF(); break;
                case 8: listAllIndividuals(); break;
                case 9: printEffectMatrix(); break;
                case 0: break;
                default:
                    System.out.println("Opção inválida.");
            }

            if (op != 0) {
                System.out.print("\nENTER para continuar...");
                sc.nextLine();
            }
        } while (op != 0);

        sc.close();
    }

    private void printHeader(String title) {
        System.out.println("\n" + SEP);
        System.out.println(title);
        System.out.println(SEP);
    }

    // ============================================================
    // MAIN
    // ============================================================
    public static void main(String[] args) {
        try {
            new RoomAcousticsConsultas();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}