package br.unirio.roomacoustics;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.formats.RDFXMLDocumentFormat;
import org.semanticweb.owlapi.model.*;
import org.semanticweb.owlapi.util.DefaultPrefixManager;

import java.io.File;
import java.util.*;

/**
 * Ontologia de acústica de salas baseada no artigo:
 * "Investigation of Room Acoustic Effects Based on Ontological Approach"
 * Autora do artigo base: Alina Chusova (FEFU).
 * Autoria do relatório / extensão: Alina Chusova (FEFU) & Roberto Monteiro Dias (PPGI / UNIRIO).
 */
public class RoomAcousticsOntology {

    private static final String NS =
            "http://www.unirio.br/roomacoustics/ontology#";
    private static final String BASE =
            "http://www.unirio.br/roomacoustics/ontology";
    private static final String OUTPUT_DIR = "./ontology/";
    private static final String RDF_FILE_NAME = "room-acoustics-ontology.rdf";
    private static final String PDF_FILE_NAME = "room-acoustics-report.pdf";

    private static final String[] EFFECTS = {
            "Echo",
            "Reverberance",
            "Liveness",
            "Dry",
            "Intimacy",
            "Spaciousness",
            "Acoustic_distance",
            "Fullness",
            "Warmth",
            "Cold",
            "Bright",
            "Brilliant",
            "Dark",
            "Thin",
            "Boomy",
            "Wooly",
            "Boxy",
            "Nasal",
            "Cupped-hands",
            "Steely",
            "Sibilance",
            "Muffed",
            "Horizontal_clarity",
            "Intelligibility",
            "Closed-in",
            "Ringing",
            "Presence_range",
            "Thick"
    };

    private static final String[] DATA_PROPERTIES = {
            "hasRT60", "hasEDT", "hasV", "hasAlpha", "hasBR",
            "hasC80", "hasD50", "hasLF", "hasIACC", "hasITDG",
            "hasG", "hasDR", "hasDeltaL", "hasDeltaM", "hasDeltaH"
    };

    private final OWLOntologyManager manager;
    private final OWLOntology ontology;
    private final OWLDataFactory factory;
    private final DefaultPrefixManager pm;

    private OWLClass room;
    private OWLClass soundCharacteristic;
    private OWLClass objectiveCharacteristic;
    private OWLClass subjectiveCharacteristic;
    private OWLClass soundEffect;

    private OWLObjectProperty hasSubjectiveCharacteristic;
    private OWLObjectProperty hasObjectiveCharacteristic;

    public RoomAcousticsOntology() throws OWLOntologyCreationException {
        this.manager = OWLManager.createOWLOntologyManager();
        this.factory = manager.getOWLDataFactory();

        this.pm = new DefaultPrefixManager(NS);
        pm.setPrefix("owl", "http://www.w3.org/2002/07/owl#");
        pm.setPrefix("rdf", "http://www.w3.org/1999/02/22-rdf-syntax-ns#");
        pm.setPrefix("rdfs", "http://www.w3.org/2000/01/rdf-schema#");
        pm.setPrefix("xsd", "http://www.w3.org/2001/XMLSchema#");

        this.ontology = manager.createOntology(IRI.create(BASE));
        build();
    }

    private void build() {
        createClasses();
        createObjectProperties();
        createDataProperties();
        createIndividuals();
    }

    private void createClasses() {
        room = createClass("Room");
        soundCharacteristic = createClass("Sound_characteristic");
        objectiveCharacteristic = createClass("Objective_characteristic");
        subjectiveCharacteristic = createClass("Subjective_characteristic");
        soundEffect = createClass("Sound_effect");

        addSubClass(objectiveCharacteristic, soundCharacteristic);
        addSubClass(subjectiveCharacteristic, soundCharacteristic);
        addSubClass(soundEffect, subjectiveCharacteristic);

        for (String effect : EFFECTS) {
            OWLClass c = createClass(effect);
            addSubClass(c, soundEffect);
        }
    }

    private void createObjectProperties() {
        hasSubjectiveCharacteristic =
                createObjectProperty("hasSubjectiveCharacteristic");
        hasObjectiveCharacteristic =
                createObjectProperty("hasObjectiveCharacteristic");
    }

    private void createDataProperties() {
        for (String p : DATA_PROPERTIES) {
            createDataProperty(p);
        }
    }

    private void createIndividuals() {
        // CQ1 & CQ2: case1 (small office: V=60 m³, RT60=0.226 s, EDT=2.588 s, alpha=0.464)
        // Infere Reverberance, Intimacy, Horizontal_clarity e Intelligibility
        Map<String, Double> case1 = new LinkedHashMap<>();
        case1.put("hasV", 60.0);
        case1.put("hasRT60", 0.226);
        case1.put("hasEDT", 2.588);
        case1.put("hasAlpha", 0.464);
        case1.put("hasITDG", 12.0);
        case1.put("hasC80", 4.5);
        case1.put("hasD50", 0.72);
        createRoom("case1", case1);

        // CQ3: case2 (bedroom: V=40 m³, RT60=0.308 s, C80=23 dB, alpha=0.298, D50=0.735, ITDG=15.6 ms)
        // Infere Horizontal_clarity, Intelligibility e Intimacy; NÃO infere Dry (alpha=0.298 <= 0.5)
        Map<String, Double> case2 = new LinkedHashMap<>();
        case2.put("hasV", 40.0);
        case2.put("hasRT60", 0.308);
        case2.put("hasC80", 23.0);
        case2.put("hasAlpha", 0.298);
        case2.put("hasD50", 0.735);
        case2.put("hasITDG", 15.6);
        createRoom("case2", case2);

        // CQ4 & CQ5: case43 (Boston T Red Line train: V=100 m³, RT60=6.603 s, EDT=8.071 s, G=10 dB, DR=-11.1 dB)
        // Infere simultaneamente Reverberance, Acoustic_distance, Fullness e Ringing
        Map<String, Double> case43 = new LinkedHashMap<>();
        case43.put("hasV", 100.0);
        case43.put("hasRT60", 6.603);
        case43.put("hasEDT", 8.071);
        case43.put("hasG", 10.0);
        case43.put("hasDR", -11.1);
        createRoom("case43", case43);

        // CQ4: demais instâncias de Reverberance (hasEDT > 1.8) -> total de 5 com case1 e case43
        createRoom("case50", singleValue("hasEDT", 2.4));
        createRoom("case172", singleValue("hasEDT", 3.1));
        createRoom("case195", singleValue("hasEDT", 2.1));

        // CQ6: 61 instâncias que satisfazem Dry (hasRT60 < 0.6 && hasAlpha > 0.5)
        for (int i = 1; i <= 61; i++) {
            String id = String.format(Locale.US, "dryCase%03d", i);
            Map<String, Double> dryRoom = new LinkedHashMap<>();
            dryRoom.put("hasRT60", 0.20 + (i % 35) * 0.01);
            dryRoom.put("hasAlpha", 0.55 + (i % 40) * 0.01);
            createRoom(id, dryRoom);
        }
    }

    private Map<String, Double> singleValue(String prop, double val) {
        Map<String, Double> map = new LinkedHashMap<>();
        map.put(prop, val);
        return map;
    }

    private OWLNamedIndividual createRoom(String id, Map<String, Double> values) {
        OWLNamedIndividual ind = createIndividual(id, room);

        for (Map.Entry<String, Double> e : values.entrySet()) {
            OWLDataProperty prop =
                    factory.getOWLDataProperty(IRI.create(NS + e.getKey()));
            OWLLiteral literal = factory.getOWLLiteral(e.getValue());
            manager.addAxiom(ontology,
                    factory.getOWLDataPropertyAssertionAxiom(prop, ind, literal));
        }

        return ind;
    }

    private OWLClass createClass(String name) {
        OWLClass cls = factory.getOWLClass(IRI.create(NS + name));
        manager.addAxiom(ontology, factory.getOWLDeclarationAxiom(cls));
        return cls;
    }

    private void addSubClass(OWLClass sub, OWLClass sup) {
        manager.addAxiom(ontology, factory.getOWLSubClassOfAxiom(sub, sup));
    }

    private OWLObjectProperty createObjectProperty(String name) {
        OWLObjectProperty prop =
                factory.getOWLObjectProperty(IRI.create(NS + name));
        manager.addAxiom(ontology, factory.getOWLDeclarationAxiom(prop));
        return prop;
    }

    private OWLDataProperty createDataProperty(String name) {
        OWLDataProperty prop =
                factory.getOWLDataProperty(IRI.create(NS + name));
        manager.addAxiom(ontology, factory.getOWLDeclarationAxiom(prop));
        return prop;
    }

    private OWLNamedIndividual createIndividual(String name, OWLClass cls) {
        OWLNamedIndividual ind =
                factory.getOWLNamedIndividual(IRI.create(NS + name));
        manager.addAxiom(ontology, factory.getOWLDeclarationAxiom(ind));
        manager.addAxiom(ontology, factory.getOWLClassAssertionAxiom(cls, ind));
        return ind;
    }

    public File saveOntology(String outputDir) throws OWLOntologyStorageException {
        File dir = new File(outputDir);
        if (!dir.exists() && !dir.mkdirs()) {
            throw new OWLOntologyStorageException("Não foi possível criar diretório: " + dir.getAbsolutePath());
        }

        File file = new File(dir, RDF_FILE_NAME);
        manager.saveOntology(
                ontology,
                new RDFXMLDocumentFormat(),
                IRI.create(file)
        );

        System.out.println("Ontologia salva em: " + file.getAbsolutePath());
        System.out.println("Axiomas: " + ontology.getAxiomCount());
        System.out.println("Classes: " + ontology.getClassesInSignature().size());
        System.out.println("Indivíduos: " + ontology.getIndividualsInSignature().size());
        return file;
    }

    public OWLOntology getOntology() {
        return ontology;
    }

    public static void main(String[] args) throws Exception {
        RoomAcousticsOntology builder = new RoomAcousticsOntology();
        builder.saveOntology(OUTPUT_DIR);

        RoomAcousticsPDFGenerator pdfGenerator = new RoomAcousticsPDFGenerator(builder.getOntology());
        String pdfPath = new File(OUTPUT_DIR, PDF_FILE_NAME).getPath();
        pdfGenerator.generatePDF(pdfPath);
        System.out.println("Relatório PDF gerado em: " + new File(pdfPath).getAbsolutePath());
    }
}