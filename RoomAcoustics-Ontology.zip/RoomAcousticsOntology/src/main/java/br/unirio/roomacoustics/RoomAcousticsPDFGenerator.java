package br.unirio.roomacoustics;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.*;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.structural.StructuralReasonerFactory;

import com.itextpdf.kernel.colors.Color;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.element.Text;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.UnitValue;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * Gerador de relatório PDF da Room Acoustics Ontology.
 * Baseado em: "Investigation of Room Acoustic Effects Based on Ontological Approach" (Alina Chusova).
 * Autoria do relatório / extensão: Alina Chusova (FEFU) e Roberto Monteiro Dias (PPGI / UNIRIO).
 */
public class RoomAcousticsPDFGenerator {

    private static final String NS =
            "http://www.unirio.br/roomacoustics/ontology#";

    private static final String DEFAULT_ONTOLOGY_DIR =
            "./ontology/";

    private static final String DEFAULT_ONTOLOGY_PATH =
            "./ontology/room-acoustics-ontology.rdf";

    private static final String DEFAULT_PDF_PATH =
            "./ontology/room-acoustics-report.pdf";

    private static final int EXPECTED_MIN_ROOMS = 67;

    private static final Color AC_BLUE       = new DeviceRgb(20, 50, 120);
    private static final Color AC_LIGHT_BLUE = new DeviceRgb(230, 240, 250);
    private static final Color AC_DARK_GRAY  = new DeviceRgb(50, 50, 50);
    private static final Color AC_GREEN      = new DeviceRgb(0, 130, 60);
    private static final Color AC_RED        = new DeviceRgb(180, 10, 40);

    @FunctionalInterface
    private interface AcousticsRule {
        boolean matches(Map<String, Double> values);
    }

    private static final String[][] OBJECTIVE_PARAMS = {
        {"RT60",  "Reverberation time (60 dB decay)",             "hasRT60"},
        {"EDT",   "Early decay time",                             "hasEDT"},
        {"V",     "Room volume (m³)",                             "hasV"},
        {"alpha", "Sound absorption coefficient",                 "hasAlpha"},
        {"BR",    "Bass ratio (125–250 Hz / 500–1000 Hz)",        "hasBR"},
        {"C80",   "Clarity index (early/late energy)",            "hasC80"},
        {"D50",   "Definition (early 50 ms proportion)",          "hasD50"},
        {"LF",    "Lateral energy fraction",                      "hasLF"},
        {"IACC",  "Interaural cross-correlation coefficient",     "hasIACC"},
        {"ITDG",  "Initial time-delay gap (ms)",                  "hasITDG"},
        {"G",     "Sound intensity relative to free field",       "hasG"},
        {"DR",    "Direct-to-reverberant ratio",                  "hasDR"},
        {"dL",    "Low-frequency deviation from spectrum",        "hasDeltaL"},
        {"dM",    "Mid-frequency deviation from spectrum",        "hasDeltaM"},
        {"dH",    "High-frequency deviation from spectrum",       "hasDeltaH"}
    };

    private static final String[][] EFFECTS_28 = {
        {"Echo",               "Sound reflection returning as a recognizable repetition"},
        {"Reverberance",       "Succession of reflections blending into fading sound"},
        {"Liveness",           "Space with a great deal of reverberation"},
        {"Dry",                "Deficient in reverberation / very short RT"},
        {"Intimacy",           "Perceived closeness of source to listener"},
        {"Spaciousness",       "Broad impression of acoustic ambience"},
        {"Acoustic_distance",  "Distant/set-back impression with acoustic depth"},
        {"Fullness",           "Rounded, robust sound with a sense of body"},
        {"Warmth",             "Milder form of dark tonal balance"},
        {"Cold",               "Cool balance with strong upper-range output"},
        {"Bright",             "Hard, crisp edge around 4–8 kHz"},
        {"Brilliant",          "More pronounced bright/hard quality"},
        {"Dark",               "Warm, mellow, rich balance"},
        {"Thin",               "Very weak bass, often below ~500 Hz"},
        {"Boomy",              "Exaggerated midbass in a narrow frequency region"},
        {"Wooly",              "Loose, poorly defined bass"},
        {"Boxy",               "Box-like 'oh' coloration (cabinet resonances)"},
        {"Nasal",              "Nose-blocked-speech-like coloration ('eh')"},
        {"Cupped-hands",       "Coloration like speaking through cupped hands"},
        {"Steely",             "Shrill, hard-edged quality"},
        {"Sibilance",          "Exaggerated vocal 's' sound"},
        {"Muffed",             "Very dull with little apparent HF content"},
        {"Horizontal_clarity", "Less reverberant smearing of musical elements"},
        {"Intelligibility",    "Ease of following speech/musical lines clearly"},
        {"Closed-in",          "Lacking openness, air, and fine detail"},
        {"Ringing",            "Audible trace of resonance"},
        {"Presence_range",     "1–3 kHz region contributing to presence"},
        {"Thick",              "Heavy or overly dense bass"}
    };

    private static final String[][] SWRL_RULES = {
        {"Echo",               "RT60 > 1.5 AND V > 1000 AND DR < -5"},
        {"Reverberance",       "EDT > 1.8"},
        {"Liveness",           "RT60 > 1.0 AND RT60 < 1.8 AND G > 0"},
        {"Dry",                "RT60 < 0.6 AND alpha > 0.5"},
        {"Intimacy",           "ITDG < 20"},
        {"Spaciousness",       "LF > 0.2 AND IACC < 0.35"},
        {"Acoustic_distance",  "DR < -8"},
        {"Fullness",           "G > 5 AND RT60 > 1.2"},
        {"Warmth",             "BR > 1.1 AND BR < 1.45"},
        {"Cold",               "BR < 0.9"},
        {"Bright",             "dH > 2 AND dH < 6"},
        {"Brilliant",          "dH > 5"},
        {"Dark",               "dH < -3"},
        {"Thin",               "dL < -4"},
        {"Boomy",              "dL > 5 AND RT60 > 1.0"},
        {"Wooly",              "dL > 3"},
        {"Boxy",               "dM > 4"},
        {"Nasal",              "dM > 3"},
        {"Cupped-hands",       "dM > 5"},
        {"Steely",             "dH > 6"},
        {"Sibilance",          "dH > 4"},
        {"Muffed",             "alpha > 0.7 AND dH < -5"},
        {"Horizontal_clarity", "C80 > 2"},
        {"Intelligibility",    "D50 > 0.5"},
        {"Closed-in",          "C80 < -2 AND G < -2"},
        {"Ringing",            "RT60 > 2.5 AND V < 200"},
        {"Presence_range",     "dM > 2 AND C80 > 1"},
        {"Thick",              "dL > 4"}
    };

    private static final String[][] METRICS_MIT = {
        {"Echo",               "1.000", "0.500", "0.995", "0.667"},
        {"Reverberance",       "0.200", "0.048", "0.880", "0.077"},
        {"Liveness",           "0.048", "1.000", "0.900", "0.091"},
        {"Dry",                "0.951", "0.504", "0.700", "0.659"},
        {"Intimacy",           "0.320", "1.000", "0.830", "0.485"},
        {"Spaciousness",       "1.000", "0.512", "0.900", "0.677"},
        {"Acoustic_distance",  "1.000", "0.714", "0.990", "0.833"},
        {"Fullness",           "1.000", "0.724", "0.960", "0.840"},
        {"Horizontal_clarity", "1.000", "1.000", "1.000", "1.000"},
        {"Intelligibility",    "1.000", "0.995", "0.995", "0.997"},
        {"Ringing",            "1.000", "0.667", "0.995", "0.800"}
    };

    private final OWLOntology ontology;
    private final OWLDataFactory factory;
    private final OWLReasoner reasoner;
    private final OWLClass classRoom;

    private final Map<String, OWLDataProperty> dataProperties = new LinkedHashMap<>();
    private final Map<String, AcousticsRule> rules = new LinkedHashMap<>();
    private final Map<String, Double> jnd = new HashMap<>();

    private PdfFont fontNormal;
    private PdfFont fontBold;
    private PdfFont fontItalic;

    public RoomAcousticsPDFGenerator() throws Exception {
        this(loadOrRefreshOntology());
    }

    public RoomAcousticsPDFGenerator(OWLOntology ontology) {
        if (ontology == null) {
            throw new IllegalArgumentException("Ontologia nula.");
        }
        this.ontology = ontology;
        OWLOntologyManager manager = ontology.getOWLOntologyManager();
        this.factory = manager.getOWLDataFactory();
        this.reasoner = new StructuralReasonerFactory().createReasoner(ontology);
        this.classRoom = factory.getOWLClass(IRI.create(NS + "Room"));

        resolveDataProperties();
        initJND();
        initRules();
    }

    private static OWLOntology loadOrRefreshOntology() throws Exception {
        File f = new File(DEFAULT_ONTOLOGY_PATH);
        if (!f.exists()) {
            RoomAcousticsOntology builder = new RoomAcousticsOntology();
            builder.saveOntology(DEFAULT_ONTOLOGY_DIR);
            return builder.getOntology();
        }

        OWLOntologyManager mgr = OWLManager.createOWLOntologyManager();
        OWLOntology loaded = mgr.loadOntologyFromOntologyDocument(f);
        OWLClass roomCls = mgr.getOWLDataFactory().getOWLClass(IRI.create(NS + "Room"));
        int roomCount = loaded.getClassAssertionAxioms(roomCls).size();

        if (roomCount < EXPECTED_MIN_ROOMS) {
            System.out.println("Ontologia em disco desatualizada (" + roomCount
                    + " salas). Regenerando automaticamente...");
            RoomAcousticsOntology builder = new RoomAcousticsOntology();
            builder.saveOntology(DEFAULT_ONTOLOGY_DIR);
            return builder.getOntology();
        }

        return loaded;
    }

    private void resolveDataProperties() {
        for (OWLDataProperty dp : ontology.getDataPropertiesInSignature()) {
            String name = dp.getIRI().getShortForm();
            if (name.startsWith("has")) {
                dataProperties.put(name, dp);
            }
        }
    }

    private void initJND() {
        jnd.put("hasRT60",   0.05);
        jnd.put("hasEDT",    0.05);
        jnd.put("hasV",      0.10);
        jnd.put("hasAlpha",  0.05);
        jnd.put("hasBR",     0.05);
        jnd.put("hasC80",    1.0);
        jnd.put("hasD50",    0.05);
        jnd.put("hasLF",     0.05);
        jnd.put("hasIACC",   0.075);
        jnd.put("hasITDG",   5.0);
        jnd.put("hasG",      1.0);
        jnd.put("hasDR",     1.0);
        jnd.put("hasDeltaL", 1.0);
        jnd.put("hasDeltaM", 1.0);
        jnd.put("hasDeltaH", 1.0);
    }

    private void initRules() {
        rules.put("Echo", m ->
                v(m, "hasRT60") > 1.5 && v(m, "hasV") > 1000 && v(m, "hasDR") < -5);
        rules.put("Reverberance", m -> v(m, "hasEDT") > 1.8);
        rules.put("Liveness", m ->
                v(m, "hasRT60") > 1.0 && v(m, "hasRT60") < 1.8 && v(m, "hasG") > 0);
        rules.put("Dry", m ->
                v(m, "hasRT60") < 0.6 && v(m, "hasAlpha") > 0.5);
        rules.put("Intimacy", m -> v(m, "hasITDG") < 20);
        rules.put("Spaciousness", m ->
                v(m, "hasLF") > 0.2 && v(m, "hasIACC") < 0.35);
        rules.put("Acoustic_distance", m -> v(m, "hasDR") < -8);
        rules.put("Fullness", m ->
                v(m, "hasG") > 5 && v(m, "hasRT60") > 1.2);
        rules.put("Warmth", m ->
                v(m, "hasBR") > 1.1 && v(m, "hasBR") < 1.45);
        rules.put("Cold", m -> v(m, "hasBR") < 0.9);
        rules.put("Bright", m ->
                v(m, "hasDeltaH") > 2 && v(m, "hasDeltaH") < 6);
        rules.put("Brilliant", m -> v(m, "hasDeltaH") > 5);
        rules.put("Dark", m -> v(m, "hasDeltaH") < -3);
        rules.put("Thin", m -> v(m, "hasDeltaL") < -4);
        rules.put("Boomy", m ->
                v(m, "hasDeltaL") > 5 && v(m, "hasRT60") > 1.0);
        rules.put("Wooly", m -> v(m, "hasDeltaL") > 3);
        rules.put("Boxy", m -> v(m, "hasDeltaM") > 4);
        rules.put("Nasal", m -> v(m, "hasDeltaM") > 3);
        rules.put("Cupped-hands", m -> v(m, "hasDeltaM") > 5);
        rules.put("Steely", m -> v(m, "hasDeltaH") > 6);
        rules.put("Sibilance", m -> v(m, "hasDeltaH") > 4);
        rules.put("Muffed", m ->
                v(m, "hasAlpha") > 0.7 && v(m, "hasDeltaH") < -5);
        rules.put("Horizontal_clarity", m -> v(m, "hasC80") > 2);
        rules.put("Intelligibility", m -> v(m, "hasD50") > 0.5);
        rules.put("Closed-in", m ->
                v(m, "hasC80") < -2 && v(m, "hasG") < -2);
        rules.put("Ringing", m ->
                v(m, "hasRT60") > 2.5 && v(m, "hasV") < 200);
        rules.put("Presence_range", m ->
                v(m, "hasDeltaM") > 2 && v(m, "hasC80") > 1);
        rules.put("Thick", m -> v(m, "hasDeltaL") > 4);
    }

    private static double v(Map<String, Double> m, String k) {
        return m.getOrDefault(k, Double.NaN);
    }

    private Map<String, Double> readValues(OWLNamedIndividual room) {
        Map<String, Double> values = new LinkedHashMap<>();
        for (OWLDataPropertyAssertionAxiom ax :
                ontology.getDataPropertyAssertionAxioms(room)) {
            String key = ax.getProperty().asOWLDataProperty().getIRI().getShortForm();
            try {
                values.put(key, Double.parseDouble(ax.getObject().getLiteral()));
            } catch (Exception ignored) { }
        }
        return values;
    }

    private Set<String> inferEffects(OWLNamedIndividual room) {
        Map<String, Double> values = readValues(room);
        Set<String> effects = new LinkedHashSet<>();
        for (Map.Entry<String, AcousticsRule> e : rules.entrySet()) {
            try {
                if (e.getValue().matches(values)) {
                    effects.add(e.getKey());
                }
            } catch (Exception ignored) { }
        }
        return effects;
    }

    private List<OWLNamedIndividual> getRooms() {
        Set<OWLNamedIndividual> rooms = new LinkedHashSet<>();
        try {
            rooms.addAll(reasoner.getInstances(classRoom, false).getFlattened());
        } catch (Exception ignored) { }

        if (rooms.isEmpty()) {
            for (OWLClassAssertionAxiom ax : ontology.getClassAssertionAxioms(classRoom)) {
                if (ax.getIndividual().isNamed()) {
                    rooms.add(ax.getIndividual().asOWLNamedIndividual());
                }
            }
        }

        List<OWLNamedIndividual> list = new ArrayList<>(rooms);
        list.sort(Comparator.comparing(r -> r.getIRI().getShortForm()));
        return list;
    }

    private OWLNamedIndividual getRoom(String id) {
        return factory.getOWLNamedIndividual(IRI.create(NS + id));
    }

    private double confidence(String param, double measured, double threshold) {
        Double j = jnd.get(param);
        if (j == null || j == 0) return Double.NaN;
        return Math.abs(measured - threshold) / j;
    }

    private String classifyConfidence(double c) {
        if (Double.isNaN(c)) return "n/a";
        if (c < 1) return "boundary";
        if (c < 3) return "high";
        return "very high";
    }

    public void generatePDF(String outputPath) throws IOException {
        File out = new File(outputPath);
        if (out.getParentFile() != null && !out.getParentFile().exists()) {
            out.getParentFile().mkdirs();
        }

        try (PdfDocument pdfDoc = new PdfDocument(new PdfWriter(out))) {
            pdfDoc.setDefaultPageSize(PageSize.A4);
            Document doc = new Document(pdfDoc);
            doc.setMargins(40, 40, 40, 40);

            fontNormal = PdfFontFactory.createFont("Helvetica");
            fontBold   = PdfFontFactory.createFont("Helvetica-Bold");
            fontItalic = PdfFontFactory.createFont("Helvetica-Oblique");

            buildHeader(doc);
            buildAbstract(doc);
            buildSectionI_CompetencyQuestions(doc);
            buildSectionII_ObjectiveParameters(doc);
            buildSectionIII_SubjectiveEffects(doc);
            buildSectionIV_SWRLRules(doc);
            buildSectionV_ExperimentalResults(doc);
            buildReferences(doc);

            doc.close();
        }
    }

    private void buildHeader(Document doc) {
        doc.add(new Paragraph("Room Acoustics Ontology")
                .setFont(fontBold).setFontSize(20)
                .setTextAlignment(TextAlignment.CENTER)
                .setFontColor(AC_BLUE));

        doc.add(new Paragraph(
                "Investigation of Room Acoustic Effects Based on Ontological Approach")
                .setFont(fontBold).setFontSize(11)
                .setTextAlignment(TextAlignment.CENTER)
                .setFontColor(AC_DARK_GRAY));

        doc.add(new Paragraph(
                "SWRL-based inference for objective-to-subjective mapping according to ISO 3382-1:2009")
                .setFont(fontItalic).setFontSize(9)
                .setTextAlignment(TextAlignment.CENTER)
                .setFontColor(AC_DARK_GRAY));

        Paragraph authors = new Paragraph()
                .setFont(fontNormal).setFontSize(10)
                .setTextAlignment(TextAlignment.CENTER)
                .setFontColor(AC_DARK_GRAY);
        authors.add(new Text("Alina Chusova — Far Eastern Federal University (FEFU)\n").setFont(fontBold));
        authors.add(new Text("Roberto Monteiro Dias — PPGI / UNIRIO\n").setFont(fontBold));
        doc.add(authors);

        Paragraph meta = new Paragraph()
                .setTextAlignment(TextAlignment.CENTER)
                .setFontSize(9).setFontColor(AC_DARK_GRAY);
        meta.add(new Text("Data: ").setFont(fontBold));
        meta.add(new Text(java.time.LocalDate.now() + "   "));
        meta.add(new Text("Salas na ontologia: ").setFont(fontBold));
        meta.add(new Text(String.valueOf(getRooms().size()) + "   "));
        meta.add(new Text("Axiomas: ").setFont(fontBold));
        meta.add(new Text(String.valueOf(ontology.getAxiomCount())));
        doc.add(meta);
        doc.add(new Paragraph(" ").setFontSize(6));
    }

    private void buildAbstract(Document doc) {
        doc.add(sectionTitle("Resumo"));
        doc.add(new Paragraph(
                "This report presents the Room Acoustics Ontology, a domain ontology designed to "
                + "compare objective acoustic characteristics of rooms with their corresponding "
                + "subjective sound effects using SWRL rules derived from ISO 3382-1:2009, GOST "
                + "standards and psychoacoustic literature (Beranek, Barron, Kuttruff, Toole). "
                + "Across 300 room profiles (200 MIT IR Survey for 11 spatiotemporal/energy effects "
                + "and 100 literature profiles for 17 spectral/coupled-volume effects), the system "
                + "achieves Micro-F1 = 0.885, Macro-F1 = 0.841 and label-wise accuracy = 0.952.")
                .setFont(fontItalic).setFontSize(9)
                .setTextAlignment(TextAlignment.JUSTIFIED));
    }

    private void buildSectionI_CompetencyQuestions(Document doc) {
        doc.add(sectionTitle("I. QUESTÕES DE COMPETÊNCIA (CQ1–CQ6)"));
        buildCQ1(doc);
        buildCQ2(doc);
        buildCQ3(doc);
        buildCQ4(doc);
        buildCQ5(doc);
        buildCQ6(doc);
    }

    private void buildCQ1(Document doc) {
        Set<String> inf = inferEffects(getRoom("case1"));
        String[] asked = {"Reverberance", "Intimacy", "Horizontal_clarity", "Intelligibility"};
        String params = summarizeValues(readValues(getRoom("case1")));

        Table t = baseTable(new float[]{35, 20, 45});
        addHeaderRow(t, "Efeito", "Inferido?", "Parâmetros case1");
        for (String e : asked) {
            boolean ok = inf.contains(e);
            addRow(t, new String[]{e, ok ? "SIM" : "NÃO", params}, ok ? AC_GREEN : AC_RED);
        }
        boolean all = inf.containsAll(Arrays.asList(asked));

        doc.add(new Paragraph("CQ1. Are Reverberance, Intimacy, Horizontal_clarity and Intelligibility inferred for case1?")
                .setFont(fontBold).setFontSize(9).setFontColor(AC_BLUE));
        doc.add(t);
        doc.add(new Paragraph("Resposta: " + (all
                ? "SIM — os quatro efeitos são inferidos para case1."
                : "NÃO — apenas parte dos efeitos foi inferida."))
                .setFont(fontBold).setFontSize(9).setFontColor(all ? AC_GREEN : AC_RED));
    }

    private void buildCQ2(Document doc) {
        doc.add(new Paragraph("CQ2. Which class is inferred when EDT > 1.8 s, and to which parent class does it belong?")
                .setFont(fontBold).setFontSize(9).setFontColor(AC_BLUE));
        Table t = baseTable(new float[]{25, 40, 35});
        addHeaderRow(t, "Nível", "Classe", "Relação");
        addRow(t, new String[]{"Inferida", "Reverberance", "SWRL: EDT > 1.8"}, AC_GREEN);
        addRow(t, new String[]{"Pai", "Sound_effect", "subClassOf"}, AC_DARK_GRAY);
        addRow(t, new String[]{"Superclasse", "Subjective_characteristic", "subClassOf"}, AC_DARK_GRAY);
        doc.add(t);
    }

    private void buildCQ3(Document doc) {
        Set<String> inf = inferEffects(getRoom("case2"));
        String[] asked = {"Dry", "Horizontal_clarity", "Intelligibility", "Intimacy"};
        String params = summarizeValues(readValues(getRoom("case2")));

        Table t = baseTable(new float[]{35, 20, 45});
        addHeaderRow(t, "Efeito", "Inferido?", "Parâmetros case2");
        for (String e : asked) {
            boolean ok = inf.contains(e);
            addRow(t, new String[]{e, ok ? "SIM" : "NÃO", params}, ok ? AC_GREEN : AC_RED);
        }

        doc.add(new Paragraph("CQ3. Which subjective effects among Dry, Horizontal_clarity, Intelligibility and Intimacy are inferred for case2?")
                .setFont(fontBold).setFontSize(9).setFontColor(AC_BLUE));
        doc.add(t);
        doc.add(new Paragraph("Resposta: Horizontal_clarity, Intelligibility e Intimacy são inferidos; Dry NÃO (alpha=0.298 <= 0.5).")
                .setFont(fontBold).setFontSize(9).setFontColor(AC_BLUE));
    }

    private void buildCQ4(Document doc) {
        List<String[]> rows = new ArrayList<>();
        for (OWLNamedIndividual r : getRooms()) {
            if (inferEffects(r).contains("Reverberance")) {
                Map<String, Double> vals = readValues(r);
                double edt = vals.getOrDefault("hasEDT", Double.NaN);
                String edtS = Double.isNaN(edt) ? "-" : String.format(Locale.US, "%.3f", edt);
                String conf = Double.isNaN(edt) ? "-" : classifyConfidence(confidence("hasEDT", edt, 1.8));
                rows.add(new String[]{r.getIRI().getShortForm(), "SIM", edtS, conf});
            }
        }

        Table t = baseTable(new float[]{30, 25, 25, 20});
        addHeaderRow(t, "Room", "Reverberance?", "EDT (s)", "Confiança");
        for (String[] row : rows) {
            addRow(t, row, AC_GREEN);
        }

        doc.add(new Paragraph("CQ4. Which records are assigned the class Reverberance?")
                .setFont(fontBold).setFontSize(9).setFontColor(AC_BLUE));
        doc.add(t);
        doc.add(new Paragraph("Total de registros com Reverberance: " + rows.size())
                .setFont(fontBold).setFontSize(9).setFontColor(AC_GREEN));
    }

    private void buildCQ5(Document doc) {
        Set<String> inf = inferEffects(getRoom("case43"));
        String[] asked = {"Reverberance", "Acoustic_distance", "Fullness", "Ringing"};
        String params = summarizeValues(readValues(getRoom("case43")));

        Table t = baseTable(new float[]{35, 20, 45});
        addHeaderRow(t, "Efeito", "Inferido?", "Parâmetros case43");
        for (String e : asked) {
            boolean ok = inf.contains(e);
            addRow(t, new String[]{e, ok ? "SIM" : "NÃO", params}, ok ? AC_GREEN : AC_RED);
        }
        boolean all = inf.containsAll(Arrays.asList(asked));

        doc.add(new Paragraph("CQ5. For the case43 record, are Reverberance, Acoustic_distance, Fullness, and Ringing all inferred simultaneously?")
                .setFont(fontBold).setFontSize(9).setFontColor(AC_BLUE));
        doc.add(t);
        doc.add(new Paragraph("Resposta: " + (all
                ? "SIM — os quatro efeitos são inferidos simultaneamente."
                : "NÃO — nem todos os quatro efeitos foram inferidos."))
                .setFont(fontBold).setFontSize(9).setFontColor(all ? AC_GREEN : AC_RED));
    }

    private void buildCQ6(Document doc) {
        int dryCount = 0;
        for (OWLNamedIndividual r : getRooms()) {
            if (inferEffects(r).contains("Dry")) {
                dryCount++;
            }
        }
        Table t = baseTable(new float[]{35, 35, 30});
        addHeaderRow(t, "Classe", "Regra SWRL", "Total inferido");
        addRow(t, new String[]{"Dry", "RT60 < 0.6 AND alpha > 0.5", String.valueOf(dryCount)}, AC_GREEN);

        doc.add(new Paragraph("CQ6. How many records are assigned the class Dry?")
                .setFont(fontBold).setFontSize(9).setFontColor(AC_BLUE));
        doc.add(t);
        doc.add(new Paragraph("Total de registros com Dry: " + dryCount)
                .setFont(fontBold).setFontSize(9).setFontColor(AC_GREEN));
    }

    private void buildSectionII_ObjectiveParameters(Document doc) {
        doc.add(sectionTitle("II. 15 PARÂMETROS OBJETIVOS"));
        Table t = baseTable(new float[]{10, 20, 45, 25});
        addHeaderRow(t, "#", "Parâmetro", "Descrição", "Propriedade OWL");
        for (int i = 0; i < OBJECTIVE_PARAMS.length; i++) {
            String[] p = OBJECTIVE_PARAMS[i];
            boolean ok = dataProperties.containsKey(p[2]);
            addRow(t, new String[]{
                    String.valueOf(i + 1),
                    p[0],
                    p[1],
                    ok ? p[2] : p[2] + " (não declarada)"
            }, ok ? AC_DARK_GRAY : AC_RED);
        }
        doc.add(t);
    }

    private void buildSectionIII_SubjectiveEffects(Document doc) {
        doc.add(sectionTitle("III. 28 EFEITOS SUBJETIVOS"));
        Table t = baseTable(new float[]{10, 30, 60});
        addHeaderRow(t, "#", "Efeito", "Descrição");
        for (int i = 0; i < EFFECTS_28.length; i++) {
            addRow(t, new String[]{String.valueOf(i + 1), EFFECTS_28[i][0], EFFECTS_28[i][1]}, AC_DARK_GRAY);
        }
        doc.add(t);
    }

    private void buildSectionIV_SWRLRules(Document doc) {
        doc.add(sectionTitle("IV. REGRAS SWRL (Tabela I)"));
        Table t = baseTable(new float[]{35, 65});
        addHeaderRow(t, "Efeito Subjetivo", "Regra Lógica");
        for (String[] r : SWRL_RULES) {
            addRow(t, new String[]{r[0], r[1]}, AC_DARK_GRAY);
        }
        doc.add(t);
    }

    private void buildSectionV_ExperimentalResults(Document doc) {
        doc.add(sectionTitle("V. MÉTRICAS EXPERIMENTAIS (Tabela IV e corpus de 300 salas)"));
        doc.add(new Paragraph(
                "Global (28 classes, 300 perfis): Micro-F1 = 0.885, Macro-F1 = 0.841, Accuracy = 0.952. "
                + "MIT IR Survey (11 classes, 200 perfis): Micro-Precision = 0.894, Micro-Recall = 0.824, "
                + "Micro-F1 = 0.858, Macro-F1 = 0.648, Accuracy = 0.922. "
                + "Literatura (17 classes, 100 perfis): Micro-Precision = 1.000, Micro-Recall = 0.925, "
                + "Micro-F1 = 0.961, Macro-F1 = 0.967, Accuracy = 0.990.")
                .setFont(fontItalic).setFontSize(8));

        Table t = baseTable(new float[]{32, 17, 17, 17, 17});
        addHeaderRow(t, "Efeito", "Precision", "Recall", "Accuracy", "F1");
        for (String[] m : METRICS_MIT) {
            addRow(t, m, AC_DARK_GRAY);
        }
        doc.add(t);
    }

    private void buildReferences(Document doc) {
        doc.add(sectionTitle("REFERÊNCIAS"));
        doc.add(new Paragraph(
                "[1] A. Chusova, \"Investigation of Room Acoustic Effects Based on Ontological Approach\", "
                + "Far Eastern Federal University, Vladivostok, Russia.\n"
                + "[2] ISO 3382-1:2009 — Acoustics — Measurement of room acoustic parameters — Part 1: Performance spaces.")
                .setFont(fontNormal).setFontSize(8));
    }

    private Paragraph sectionTitle(String text) {
        return new Paragraph(text)
                .setFont(fontBold).setFontSize(10)
                .setFontColor(AC_BLUE)
                .setMarginTop(8).setMarginBottom(3);
    }

    private Table baseTable(float[] widths) {
        Table t = new Table(UnitValue.createPercentArray(widths));
        t.setWidth(UnitValue.createPercentValue(100));
        t.setMarginBottom(4);
        return t;
    }

    private void addHeaderRow(Table t, String... cols) {
        for (String c : cols) {
            Cell cell = new Cell().add(new Paragraph(c).setFont(fontBold).setFontSize(8).setFontColor(AC_BLUE));
            cell.setBackgroundColor(AC_LIGHT_BLUE);
            t.addHeaderCell(cell);
        }
    }

    private void addRow(Table t, String[] cols, Color color) {
        for (int i = 0; i < cols.length; i++) {
            Cell cell = new Cell().add(new Paragraph(cols[i])
                    .setFont(i == 1 ? fontBold : fontNormal)
                    .setFontSize(8)
                    .setFontColor(i == 1 ? color : AC_DARK_GRAY));
            t.addCell(cell);
        }
    }

    private String summarizeValues(Map<String, Double> vals) {
        if (vals.isEmpty()) return "(sem parâmetros)";
        List<String> list = new ArrayList<>();
        for (Map.Entry<String, Double> e : vals.entrySet()) {
            list.add(e.getKey().replace("has", "") + "=" + String.format(Locale.US, "%.3f", e.getValue()));
        }
        return String.join(", ", list);
    }

    public static void main(String[] args) throws Exception {
        RoomAcousticsPDFGenerator gen = new RoomAcousticsPDFGenerator();
        gen.generatePDF(DEFAULT_PDF_PATH);
        System.out.println("Relatório PDF gerado em: " + new File(DEFAULT_PDF_PATH).getAbsolutePath());
    }
}